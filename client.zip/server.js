const contactRoute = require('./routes/contact');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const bookingsRoute = require('./routes/bookings');
const adminRoute = require('./routes/admin');




const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// API routes
app.use('/api/bookings', bookingsRoute);
app.use('/api/admin', adminRoute);
app.use('/api/contact', contactRoute);
app.use('/api/admin', adminRoute);



// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://carwashuser:ikanejoplak22@cluster0.v41nmkx.mongodb.net/carwash?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// ✅ Serve static files from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Serve index.html by default
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
